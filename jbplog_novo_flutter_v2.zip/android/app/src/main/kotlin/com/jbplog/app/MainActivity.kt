package com.jbplog.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
